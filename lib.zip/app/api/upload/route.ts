import { NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { existsSync } from "fs";
import { db } from "@/lib/db-adapter";
import heicConvert from "heic-convert";

/**
 * PDFファイルアップロードAPI
 * POST /api/upload
 * クエリパラメータ: testId (オプション: 既存テストへの添付用)
 */
export async function POST(request: Request) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File;
    const testIdParam = formData.get("testId") as string | null;

    if (!file) {
      return NextResponse.json(
        { error: "ファイルが選択されていません" },
        { status: 400 }
      );
    }

    // ファイル拡張子を取得
    const fileExt = file.name.split(".").pop()?.toLowerCase() || "";

    console.log("アップロードファイル情報:", {
      name: file.name,
      type: file.type,
      size: file.size,
      extension: fileExt,
    });

    // 許可する拡張子
    const allowedExtensions = ["pdf", "heic", "heif", "jpg", "jpeg", "png"];

    // 許可するファイルタイプ（PDFと画像のみ）
    const allowedTypes = [
      "application/pdf",
      "image/heic",
      "image/heif",
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/x-heic", // 一部ブラウザのHEIC MIMEタイプ
      "application/octet-stream", // 不明なバイナリファイル
      "", // 空のMIMEタイプ
    ];

    // 拡張子が許可リストにあればOK（HEICファイル対応）
    const isValidExtension = allowedExtensions.includes(fileExt);
    // MIMEタイプが許可リストにあればOK
    const isValidMimeType = allowedTypes.includes(file.type);

    // 拡張子が有効な場合は、MIMEタイプに関係なくアップロード許可
    // (HEICファイルは拡張子で判定)
    if (!isValidExtension && !isValidMimeType) {
      console.log("❌ ファイルタイプ拒否:", {
        fileName: file.name,
        type: file.type,
        typeLength: file.type.length,
        extension: fileExt,
        isValidExtension,
        isValidMimeType,
      });
      return NextResponse.json(
        { error: "PDF、HEIC、JPG、PNGファイルのみアップロード可能です" },
        { status: 400 }
      );
    }

    console.log("✅ ファイルタイプ承認:", {
      fileName: file.name,
      type: file.type,
      extension: fileExt,
      isValidExtension,
      isValidMimeType,
    });

    // ファイルサイズチェック(10MB制限)
    const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB
    if (file.size > MAX_FILE_SIZE) {
      return NextResponse.json(
        { error: "ファイルサイズは10MB以下にしてください" },
        { status: 400 }
      );
    }

    // testIdが指定されている場合、添付ファイル数をチェック
    if (testIdParam) {
      const testId = parseInt(testIdParam);
      const attachments = await db.all(
        "SELECT COUNT(*) as count FROM test_attachments WHERE test_id = ?",
        [testId]
      );

      const count = attachments[0]?.count || 0;
      if (count >= 5) {
        return NextResponse.json(
          { error: "添付ファイルは最大5つまでです" },
          { status: 400 }
        );
      }
    }

    // アップロードディレクトリの作成
    let uploadDir: string;
    let publicPath: string;
    let finalMimeType = file.type;
    let finalFileSize = file.size;

    if (testIdParam) {
      // テスト別フォルダに保存
      uploadDir = path.join(
        process.cwd(),
        "public",
        "uploads",
        "pdfs",
        `test_${testIdParam}`
      );
      const timestamp = Date.now();
      const randomStr = Math.random().toString(36).substring(2, 15);
      let fileExt = (file.name.split(".").pop() || "pdf").toLowerCase();

      // HEICファイルの場合はJPEGに変換
      const bytes = await file.arrayBuffer();
      let buffer = Buffer.from(bytes);

      if (
        file.type === "image/heic" ||
        file.type === "image/heif" ||
        fileExt === "heic" ||
        fileExt === "heif"
      ) {
        console.log("HEICファイルを検出、JPEG変換を開始:", file.name);
        try {
          const convertedBuffer = await heicConvert({
            buffer: buffer,
            format: "JPEG",
            quality: 0.9,
          });
          buffer = Buffer.from(convertedBuffer);
          fileExt = "jpg";
          finalMimeType = "image/jpeg";
          finalFileSize = buffer.length;
          console.log("HEIC→JPEG変換成功:", file.name, "→", fileExt);
        } catch (convertError) {
          console.error("HEIC変換エラー:", convertError);
          return NextResponse.json(
            { error: "HEICファイルの変換に失敗しました" },
            { status: 500 }
          );
        }
      }

      const fileName = `${timestamp}-${randomStr}.${fileExt}`;
      publicPath = `/uploads/pdfs/test_${testIdParam}/${fileName}`;

      if (!existsSync(uploadDir)) {
        await mkdir(uploadDir, { recursive: true });
      }

      const filePath = path.join(uploadDir, fileName);
      await writeFile(filePath, buffer);

      // データベースに記録
      const result = await db.run(
        "INSERT INTO test_attachments (test_id, file_name, file_path, mime_type, file_size) VALUES (?, ?, ?, ?, ?)",
        [
          parseInt(testIdParam),
          file.name,
          publicPath,
          finalMimeType,
          finalFileSize,
        ]
      );

      return NextResponse.json({
        success: true,
        path: publicPath,
        fileName: file.name,
        size: finalFileSize,
        mimeType: finalMimeType,
        attachmentId: result.lastInsertRowid,
        converted: file.type === "image/heic" ? "HEIC→JPEG" : null,
      });
    } else {
      // 従来通りの保存(テスト作成時の一時保存)
      uploadDir = path.join(process.cwd(), "public", "uploads", "pdfs");
      if (!existsSync(uploadDir)) {
        await mkdir(uploadDir, { recursive: true });
      }

      const timestamp = Date.now();
      const randomStr = Math.random().toString(36).substring(2, 15);
      let fileExt = (file.name.split(".").pop() || "pdf").toLowerCase();

      // HEICファイルの場合はJPEGに変換
      const bytes = await file.arrayBuffer();
      let buffer = Buffer.from(bytes);

      if (
        file.type === "image/heic" ||
        file.type === "image/heif" ||
        fileExt === "heic" ||
        fileExt === "heif"
      ) {
        console.log("HEICファイルを検出、JPEG変換を開始:", file.name);
        try {
          const convertedBuffer = await heicConvert({
            buffer: buffer,
            format: "JPEG",
            quality: 0.9,
          });
          buffer = Buffer.from(convertedBuffer);
          fileExt = "jpg";
          finalMimeType = "image/jpeg";
          finalFileSize = buffer.length;
          console.log("HEIC→JPEG変換成功:", file.name, "→", fileExt);
        } catch (convertError) {
          console.error("HEIC変換エラー:", convertError);
          return NextResponse.json(
            { error: "HEICファイルの変換に失敗しました" },
            { status: 500 }
          );
        }
      }

      const fileName = `${timestamp}-${randomStr}.${fileExt}`;
      const filePath = path.join(uploadDir, fileName);
      await writeFile(filePath, buffer);

      publicPath = `/uploads/pdfs/${fileName}`;

      return NextResponse.json({
        success: true,
        path: publicPath,
        fileName: file.name, // 元のファイル名を返す
        size: finalFileSize,
        mimeType: finalMimeType,
        converted: file.type === "image/heic" ? "HEIC→JPEG" : null,
      });
    }
  } catch (error) {
    console.error("ファイルアップロードエラー:", error);
    return NextResponse.json(
      { error: "ファイルのアップロードに失敗しました" },
      { status: 500 }
    );
  }
}
