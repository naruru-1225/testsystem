/**
 * テストデータのCSVエクスポートAPI
 * GET /api/export/tests
 *
 * クエリパラメータで絞り込んだテストデータをCSV形式でダウンロード
 */

import { NextRequest, NextResponse } from "next/server";
import db from "@/lib/database";
import type { Test, Tag, Folder, TestWithTags } from "@/types/database";

/**
 * 指定されたフォルダの子孫フォルダIDを全て取得する(再帰的)
 */
function getDescendantFolderIds(folderId: number): number[] {
  const descendants: number[] = [];
  const children = db
    .prepare("SELECT id FROM folders WHERE parent_id = ?")
    .all(folderId) as { id: number }[];

  for (const child of children) {
    descendants.push(child.id);
    // 再帰的に孫フォルダも取得
    descendants.push(...getDescendantFolderIds(child.id));
  }

  return descendants;
}

/**
 * CSV形式の文字列にエスケープ処理を施す
 * @param value エスケープ対象の値
 * @returns エスケープされた文字列
 */
function escapeCsvValue(value: any): string {
  if (value === null || value === undefined) return "";

  const str = String(value);
  // カンマ、改行、ダブルクォートを含む場合はダブルクォートで囲む
  if (str.includes(",") || str.includes("\n") || str.includes('"')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

/**
 * テストデータをCSV形式に変換
 * @param tests テストデータ配列
 * @returns CSV文字列
 */
function convertToCSV(tests: any[]): string {
  // CSVヘッダー
  const headers = [
    "ID",
    "テスト名",
    "科目",
    "学年",
    "フォルダ",
    "大問数",
    "満点",
    "説明",
    "タグ",
    "登録日",
    "更新日",
  ];

  // ヘッダー行
  const csvRows = [headers.join(",")];

  // データ行
  for (const test of tests) {
    const row = [
      escapeCsvValue(test.id),
      escapeCsvValue(test.name),
      escapeCsvValue(test.subject),
      escapeCsvValue(test.grade),
      escapeCsvValue(test.folder_name || ""),
      escapeCsvValue(test.total_questions ?? ""),
      escapeCsvValue(test.total_score ?? ""),
      escapeCsvValue(test.description ?? ""),
      escapeCsvValue(test.tags?.map((t: any) => t.name).join("; ") || ""),
      escapeCsvValue(test.created_at),
      escapeCsvValue(test.updated_at),
    ];
    csvRows.push(row.join(","));
  }

  return csvRows.join("\n");
}

/**
 * GET /api/export/tests
 * フィルタリングされたテストデータをCSV形式でエクスポート
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;

    // クエリパラメータを取得
    const folderId = searchParams.get("folderId");
    const grade = searchParams.get("grade");
    const subject = searchParams.get("subject");
    const tagId = searchParams.get("tagId");
    const search = searchParams.get("search");

    // テストデータを取得（/api/tests と同じロジック）
    let query = `
      SELECT 
        t.*,
        f.name as folder_name
      FROM tests t
      LEFT JOIN folders f ON t.folder_id = f.id
      WHERE 1=1
    `;
    const params: any[] = [];

    // フォルダでフィルタ
    if (folderId) {
      const descendantIds = getDescendantFolderIds(parseInt(folderId));
      descendantIds.push(parseInt(folderId));

      if (descendantIds.length === 1) {
        query += ` AND EXISTS (
          SELECT 1 FROM test_folders tf 
          WHERE tf.test_id = t.id AND tf.folder_id = ?
        )`;
        params.push(folderId);
      } else {
        const placeholders = descendantIds.map(() => "?").join(",");
        query += ` AND EXISTS (
          SELECT 1 FROM test_folders tf 
          WHERE tf.test_id = t.id AND tf.folder_id IN (${placeholders})
        )`;
        params.push(...descendantIds);
      }
    }

    // 学年でフィルタ
    if (grade) {
      query += " AND t.grade = ?";
      params.push(grade);
    }

    // 科目でフィルタ
    if (subject) {
      query += " AND t.subject = ?";
      params.push(subject);
    }

    // タグでフィルタ
    if (tagId) {
      query += ` AND EXISTS (
        SELECT 1 FROM test_tags tt 
        WHERE tt.test_id = t.id AND tt.tag_id = ?
      )`;
      params.push(tagId);
    }

    // 検索条件
    if (search) {
      query +=
        " AND (t.name LIKE ? OR t.subject LIKE ? OR t.grade LIKE ? OR t.description LIKE ?)";
      const searchPattern = `%${search}%`;
      params.push(searchPattern, searchPattern, searchPattern, searchPattern);
    }

    query += " ORDER BY t.created_at DESC";

    const stmt = db.prepare(query);
    const tests = stmt.all(...params) as (Test & { folder_name: string })[];

    // 各テストに紐づくタグを取得
    const testsWithTags: TestWithTags[] = tests.map((test) => {
      const tagStmt = db.prepare(`
        SELECT tg.*
        FROM tags tg
        INNER JOIN test_tags tt ON tg.id = tt.tag_id
        WHERE tt.test_id = ?
      `);
      const tags = tagStmt.all(test.id) as Tag[];

      const folderStmt = db.prepare(`
        SELECT f.*
        FROM folders f
        INNER JOIN test_folders tf ON f.id = tf.folder_id
        WHERE tf.test_id = ?
      `);
      const folders = folderStmt.all(test.id) as Folder[];

      return {
        ...test,
        tags,
        folders,
      };
    });

    // CSV形式に変換
    const csv = convertToCSV(testsWithTags);

    // BOM付きUTF-8でエンコード（Excelでの文字化け防止）
    const bom = "\uFEFF";
    const csvWithBom = bom + csv;

    // ファイル名を生成（日時を含む）
    const timestamp = new Date()
      .toISOString()
      .replace(/[:.]/g, "-")
      .split("T")[0];
    const filename = `tests_export_${timestamp}.csv`;

    // レスポンスを返す
    return new NextResponse(csvWithBom, {
      status: 200,
      headers: {
        "Content-Type": "text/csv; charset=utf-8",
        "Content-Disposition": `attachment; filename="${encodeURIComponent(
          filename
        )}"`,
      },
    });
  } catch (error) {
    console.error("CSVエクスポートエラー:", error);
    return NextResponse.json(
      { error: "CSVエクスポートに失敗しました" },
      { status: 500 }
    );
  }
}
