import { NextResponse } from "next/server";
import db from "@/lib/database";
import type { Subject } from "@/types/database";

/**
 * 科目取得API
 * GET /api/subjects/[id]
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const subjectId = parseInt(id);

    if (isNaN(subjectId)) {
      return NextResponse.json({ error: "無効な科目IDです" }, { status: 400 });
    }

    const subject = db
      .prepare("SELECT * FROM subjects WHERE id = ?")
      .get(subjectId) as Subject;

    if (!subject) {
      return NextResponse.json(
        { error: "科目が見つかりません" },
        { status: 404 }
      );
    }

    return NextResponse.json(subject);
  } catch (error: any) {
    console.error("科目取得エラー:", error);
    return NextResponse.json(
      { error: "科目の取得に失敗しました" },
      { status: 500 }
    );
  }
}

/**
 * 科目更新API
 * PUT /api/subjects/[id]
 */
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const subjectId = parseInt(id);

    if (isNaN(subjectId)) {
      return NextResponse.json({ error: "無効な科目IDです" }, { status: 400 });
    }

    const body = await request.json();
    const { name, displayOrder } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { error: "科目名が入力されていません" },
        { status: 400 }
      );
    }

    const existingSubject = db
      .prepare("SELECT id FROM subjects WHERE id = ?")
      .get(subjectId);

    if (!existingSubject) {
      return NextResponse.json(
        { error: "科目が見つかりません" },
        { status: 404 }
      );
    }

    db.prepare(
      "UPDATE subjects SET name = ?, display_order = ? WHERE id = ?"
    ).run(name.trim(), displayOrder ?? 0, subjectId);

    const updatedSubject = db
      .prepare("SELECT * FROM subjects WHERE id = ?")
      .get(subjectId) as Subject;

    return NextResponse.json(updatedSubject);
  } catch (error: any) {
    console.error("科目更新エラー:", error);

    if (error.message?.includes("UNIQUE constraint failed")) {
      return NextResponse.json(
        { error: "この科目名は既に登録されています" },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: "科目の更新に失敗しました" },
      { status: 500 }
    );
  }
}

/**
 * 科目削除API
 * DELETE /api/subjects/[id]
 */
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const subjectId = parseInt(id);

    if (isNaN(subjectId)) {
      return NextResponse.json({ error: "無効な科目IDです" }, { status: 400 });
    }

    const existingSubject = db
      .prepare("SELECT * FROM subjects WHERE id = ?")
      .get(subjectId) as Subject;

    if (!existingSubject) {
      return NextResponse.json(
        { error: "科目が見つかりません" },
        { status: 404 }
      );
    }

    // この科目を使用しているテストの数を確認
    const testCount = db
      .prepare("SELECT COUNT(*) as count FROM tests WHERE subject = ?")
      .get(existingSubject.name) as { count: number };

    if (testCount.count > 0) {
      return NextResponse.json(
        {
          error: `この科目は${testCount.count}件のテストで使用されています。先にテストを削除または変更してください。`,
        },
        { status: 409 }
      );
    }

    db.prepare("DELETE FROM subjects WHERE id = ?").run(subjectId);

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error("科目削除エラー:", error);
    return NextResponse.json(
      { error: "科目の削除に失敗しました" },
      { status: 500 }
    );
  }
}
