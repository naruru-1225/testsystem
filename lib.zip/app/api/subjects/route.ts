import { NextResponse } from "next/server";
import db from "@/lib/database";
import type { Subject } from "@/types/database";

/**
 * 科目一覧取得API
 * GET /api/subjects
 */
export async function GET() {
  try {
    const subjects = db
      .prepare("SELECT * FROM subjects ORDER BY display_order, name")
      .all() as Subject[];

    return NextResponse.json(subjects);
  } catch (error: any) {
    console.error("科目取得エラー:", error);
    return NextResponse.json(
      { error: "科目の取得に失敗しました" },
      { status: 500 }
    );
  }
}

/**
 * 科目作成API
 * POST /api/subjects
 */
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, displayOrder = 0 } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { error: "科目名が入力されていません" },
        { status: 400 }
      );
    }

    const result = db
      .prepare("INSERT INTO subjects (name, display_order) VALUES (?, ?)")
      .run(name.trim(), displayOrder);

    const newSubject = db
      .prepare("SELECT * FROM subjects WHERE id = ?")
      .get(result.lastInsertRowid) as Subject;

    return NextResponse.json(newSubject, { status: 201 });
  } catch (error: any) {
    console.error("科目作成エラー:", error);

    if (error.message?.includes("UNIQUE constraint failed")) {
      return NextResponse.json(
        { error: "この科目名は既に登録されています" },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: "科目の作成に失敗しました" },
      { status: 500 }
    );
  }
}
