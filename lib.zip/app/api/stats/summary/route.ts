/**
 * 統計情報API
 * GET /api/stats/summary
 *
 * @description
 * システム全体の統計データを返します:
 * - 総テスト数、フォルダ数、タグ数
 * - 学年別・科目別のテスト数
 * - タグ使用頻度トップ10
 * - フォルダ別テスト数トップ10
 * - 最近追加されたテスト10件
 *
 * @returns 統計情報のJSON
 */

import { NextResponse } from "next/server";
import db from "@/lib/database";

/**
 * GET /api/stats/summary
 * システム統計情報を取得
 */
export async function GET() {
  try {
    // 総テスト数
    const totalTests = db
      .prepare("SELECT COUNT(*) as count FROM tests")
      .get() as { count: number };

    // 学年別テスト数
    const testsByGrade = db
      .prepare(
        `
        SELECT grade, COUNT(*) as count
        FROM tests
        GROUP BY grade
        ORDER BY count DESC
      `
      )
      .all() as { grade: string; count: number }[];

    // 科目別テスト数
    const testsBySubject = db
      .prepare(
        `
        SELECT subject, COUNT(*) as count
        FROM tests
        GROUP BY subject
        ORDER BY count DESC
      `
      )
      .all() as { subject: string; count: number }[];

    // タグ使用頻度トップ10
    const topTags = db
      .prepare(
        `
        SELECT 
          tg.id,
          tg.name,
          tg.color,
          COUNT(tt.test_id) as usage_count
        FROM tags tg
        LEFT JOIN test_tags tt ON tg.id = tt.tag_id
        GROUP BY tg.id
        ORDER BY usage_count DESC
        LIMIT 10
      `
      )
      .all() as {
      id: number;
      name: string;
      color: string;
      usage_count: number;
    }[];

    // フォルダ別テスト数（トップ10）
    const testsByFolder = db
      .prepare(
        `
        SELECT 
          f.id,
          f.name,
          COUNT(tf.test_id) as count
        FROM folders f
        LEFT JOIN test_folders tf ON f.id = tf.folder_id
        WHERE f.name != '未分類' AND f.name != 'すべてのテスト'
        GROUP BY f.id
        ORDER BY count DESC
        LIMIT 10
      `
      )
      .all() as { id: number; name: string; count: number }[];

    // 総フォルダ数
    const totalFolders = db
      .prepare(
        "SELECT COUNT(*) as count FROM folders WHERE name != '未分類' AND name != 'すべてのテスト'"
      )
      .get() as { count: number };

    // 総タグ数
    const totalTags = db
      .prepare("SELECT COUNT(*) as count FROM tags")
      .get() as { count: number };

    // PDF添付ありのテスト数
    const testsWithPdf = db
      .prepare("SELECT COUNT(*) as count FROM tests WHERE pdf_path IS NOT NULL")
      .get() as { count: number };

    // 最近追加されたテスト（直近10件）
    const recentTests = db
      .prepare(
        `
        SELECT 
          t.id,
          t.name,
          t.subject,
          t.grade,
          t.created_at,
          f.name as folder_name
        FROM tests t
        LEFT JOIN folders f ON t.folder_id = f.id
        ORDER BY t.created_at DESC
        LIMIT 10
      `
      )
      .all() as {
      id: number;
      name: string;
      subject: string;
      grade: string;
      created_at: string;
      folder_name: string;
    }[];

    // レスポンスを構築
    const summary = {
      overview: {
        totalTests: totalTests.count,
        totalFolders: totalFolders.count,
        totalTags: totalTags.count,
        testsWithPdf: testsWithPdf.count,
        testsWithoutPdf: totalTests.count - testsWithPdf.count,
      },
      testsByGrade,
      testsBySubject,
      topTags,
      testsByFolder,
      recentTests,
    };

    return NextResponse.json(summary);
  } catch (error) {
    console.error("統計情報取得エラー:", error);
    return NextResponse.json(
      { error: "統計情報の取得に失敗しました" },
      { status: 500 }
    );
  }
}
