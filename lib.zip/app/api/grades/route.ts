import { NextResponse } from "next/server";
import db from "@/lib/database";
import type { Grade } from "@/types/database";

/**
 * 学年一覧取得API
 * GET /api/grades
 */
export async function GET() {
  try {
    const grades = db
      .prepare("SELECT * FROM grades ORDER BY display_order, name")
      .all() as Grade[];

    return NextResponse.json(grades);
  } catch (error: any) {
    console.error("学年取得エラー:", error);
    return NextResponse.json(
      { error: "学年の取得に失敗しました" },
      { status: 500 }
    );
  }
}

/**
 * 学年作成API
 * POST /api/grades
 */
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { name, displayOrder = 0 } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { error: "学年名が入力されていません" },
        { status: 400 }
      );
    }

    const result = db
      .prepare("INSERT INTO grades (name, display_order) VALUES (?, ?)")
      .run(name.trim(), displayOrder);

    const newGrade = db
      .prepare("SELECT * FROM grades WHERE id = ?")
      .get(result.lastInsertRowid) as Grade;

    return NextResponse.json(newGrade, { status: 201 });
  } catch (error: any) {
    console.error("学年作成エラー:", error);

    if (error.message?.includes("UNIQUE constraint failed")) {
      return NextResponse.json(
        { error: "この学年名は既に登録されています" },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: "学年の作成に失敗しました" },
      { status: 500 }
    );
  }
}
