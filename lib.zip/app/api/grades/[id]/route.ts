import { NextResponse } from "next/server";
import db from "@/lib/database";
import type { Grade } from "@/types/database";

/**
 * 学年取得API
 * GET /api/grades/[id]
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const gradeId = parseInt(id);

    if (isNaN(gradeId)) {
      return NextResponse.json({ error: "無効な学年IDです" }, { status: 400 });
    }

    const grade = db
      .prepare("SELECT * FROM grades WHERE id = ?")
      .get(gradeId) as Grade;

    if (!grade) {
      return NextResponse.json(
        { error: "学年が見つかりません" },
        { status: 404 }
      );
    }

    return NextResponse.json(grade);
  } catch (error: any) {
    console.error("学年取得エラー:", error);
    return NextResponse.json(
      { error: "学年の取得に失敗しました" },
      { status: 500 }
    );
  }
}

/**
 * 学年更新API
 * PUT /api/grades/[id]
 */
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const gradeId = parseInt(id);

    if (isNaN(gradeId)) {
      return NextResponse.json({ error: "無効な学年IDです" }, { status: 400 });
    }

    const body = await request.json();
    const { name, displayOrder } = body;

    if (!name || !name.trim()) {
      return NextResponse.json(
        { error: "学年名が入力されていません" },
        { status: 400 }
      );
    }

    const existingGrade = db
      .prepare("SELECT id FROM grades WHERE id = ?")
      .get(gradeId);

    if (!existingGrade) {
      return NextResponse.json(
        { error: "学年が見つかりません" },
        { status: 404 }
      );
    }

    db.prepare(
      "UPDATE grades SET name = ?, display_order = ? WHERE id = ?"
    ).run(name.trim(), displayOrder ?? 0, gradeId);

    const updatedGrade = db
      .prepare("SELECT * FROM grades WHERE id = ?")
      .get(gradeId) as Grade;

    return NextResponse.json(updatedGrade);
  } catch (error: any) {
    console.error("学年更新エラー:", error);

    if (error.message?.includes("UNIQUE constraint failed")) {
      return NextResponse.json(
        { error: "この学年名は既に登録されています" },
        { status: 409 }
      );
    }

    return NextResponse.json(
      { error: "学年の更新に失敗しました" },
      { status: 500 }
    );
  }
}

/**
 * 学年削除API
 * DELETE /api/grades/[id]
 */
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const gradeId = parseInt(id);

    if (isNaN(gradeId)) {
      return NextResponse.json({ error: "無効な学年IDです" }, { status: 400 });
    }

    const existingGrade = db
      .prepare("SELECT * FROM grades WHERE id = ?")
      .get(gradeId) as Grade;

    if (!existingGrade) {
      return NextResponse.json(
        { error: "学年が見つかりません" },
        { status: 404 }
      );
    }

    // この学年を使用しているテストの数を確認
    const testCount = db
      .prepare("SELECT COUNT(*) as count FROM tests WHERE grade = ?")
      .get(existingGrade.name) as { count: number };

    if (testCount.count > 0) {
      return NextResponse.json(
        {
          error: `この学年は${testCount.count}件のテストで使用されています。先にテストを削除または変更してください。`,
        },
        { status: 409 }
      );
    }

    db.prepare("DELETE FROM grades WHERE id = ?").run(gradeId);

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error("学年削除エラー:", error);
    return NextResponse.json(
      { error: "学年の削除に失敗しました" },
      { status: 500 }
    );
  }
}
