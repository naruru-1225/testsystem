import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";
import Database from "better-sqlite3";

/**
 * バックアップ作成API
 * GET /api/backup/create
 * SQLiteのVACUUM INTOコマンドを使用して完全なバックアップを作成
 */
export async function GET() {
  let tempBackupPath: string | null = null;

  try {
    // データベースファイルのパス
    const dbPath = path.join(process.cwd(), "data", "tests.db");

    if (!fs.existsSync(dbPath)) {
      return NextResponse.json(
        { error: "データベースファイルが見つかりません" },
        { status: 404 }
      );
    }

    // 一時バックアップファイルのパス
    const timestamp = new Date().toISOString().replace(/:/g, "-").split(".")[0];
    const filename = `backup-${timestamp}.db`;
    tempBackupPath = path.join(process.cwd(), "data", filename);

    // データベースを開いてVACUUM INTOでバックアップを作成
    const db = new Database(dbPath, { readonly: true });

    try {
      // VACUUM INTOコマンドで完全なバックアップを作成
      // これにより、WALファイルの内容も含めた完全なコピーが作成される
      db.exec(`VACUUM INTO '${tempBackupPath.replace(/\\/g, "/")}'`);
    } finally {
      db.close();
    }

    // バックアップファイルを読み込む
    const backupBuffer = fs.readFileSync(tempBackupPath);

    // 一時ファイルを削除
    fs.unlinkSync(tempBackupPath);
    tempBackupPath = null;

    // レスポンスヘッダーを設定してファイルをダウンロードさせる
    return new NextResponse(backupBuffer, {
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Content-Length": backupBuffer.length.toString(),
      },
    });
  } catch (error: any) {
    console.error("Backup creation error:", error);

    // エラー時に一時ファイルが残っていれば削除
    if (tempBackupPath && fs.existsSync(tempBackupPath)) {
      try {
        fs.unlinkSync(tempBackupPath);
      } catch (cleanupError) {
        console.error("Cleanup error:", cleanupError);
      }
    }

    return NextResponse.json(
      { error: "バックアップの作成に失敗しました: " + error.message },
      { status: 500 }
    );
  }
}
