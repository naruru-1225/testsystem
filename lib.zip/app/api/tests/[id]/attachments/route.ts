import { NextResponse } from "next/server";
import { db } from "@/lib/db-adapter";
import { unlink } from "fs/promises";
import path from "path";
import { existsSync } from "fs";

/**
 * テスト添付ファイル一覧取得API
 * GET /api/tests/[id]/attachments
 */
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const testId = parseInt(id);

    const attachments = await db.all(
      "SELECT * FROM test_attachments WHERE test_id = ? ORDER BY uploaded_at DESC",
      [testId]
    );

    return NextResponse.json({ attachments });
  } catch (error) {
    console.error("添付ファイル取得エラー:", error);
    return NextResponse.json(
      { error: "添付ファイルの取得に失敗しました" },
      { status: 500 }
    );
  }
}

/**
 * テスト添付ファイル削除API
 * DELETE /api/tests/[id]/attachments?attachmentId=xxx
 */
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const testId = parseInt(id);
    const url = new URL(request.url);
    const attachmentId = url.searchParams.get("attachmentId");

    if (!attachmentId) {
      return NextResponse.json(
        { error: "添付ファイルIDが指定されていません" },
        { status: 400 }
      );
    }

    // 添付ファイル情報を取得
    const attachment = await db.get<{
      id: number;
      test_id: number;
      file_name: string;
      file_path: string;
    }>("SELECT * FROM test_attachments WHERE id = ? AND test_id = ?", [
      parseInt(attachmentId),
      testId,
    ]);

    if (!attachment) {
      return NextResponse.json(
        { error: "添付ファイルが見つかりません" },
        { status: 404 }
      );
    }

    // 物理ファイルを削除
    const filePath = path.join(process.cwd(), "public", attachment.file_path);
    if (existsSync(filePath)) {
      await unlink(filePath);
    }

    // データベースから削除
    await db.run("DELETE FROM test_attachments WHERE id = ?", [
      parseInt(attachmentId),
    ]);

    return NextResponse.json({
      success: true,
      message: "添付ファイルを削除しました",
    });
  } catch (error) {
    console.error("添付ファイル削除エラー:", error);
    return NextResponse.json(
      { error: "添付ファイルの削除に失敗しました" },
      { status: 500 }
    );
  }
}
