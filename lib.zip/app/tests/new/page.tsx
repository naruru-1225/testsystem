import TestCreateForm from "@/components/TestCreateForm";

/**
 * テスト新規登録ページ
 * パス: /tests/new
 */
export default function NewTestPage() {
  return <TestCreateForm />;
}
