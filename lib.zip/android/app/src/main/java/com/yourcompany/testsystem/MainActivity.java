package com.yourcompany.testsystem;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
