import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

/**
 * データベース管理クラス
 * SQLiteを使用したテスト管理システムのデータベース操作
 */

// データベースファイルのパス
// Vercel環境では /tmp を使用、ローカル環境では data ディレクトリを使用
const isVercel = process.env.VERCEL === "1";
const DB_DIR = isVercel ? "/tmp" : path.join(process.cwd(), "data");
const DB_PATH = path.join(DB_DIR, "tests.db");

// データディレクトリが存在しない場合は作成(ローカル環境のみ)
if (!isVercel && !fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

// データベースインスタンス
const db = new Database(DB_PATH);

// WALモードを有効化(パフォーマンス向上)
db.pragma("journal_mode = WAL");

/**
 * データベースの初期化
 * テーブルが存在しない場合は作成し、初期データを投入
 */
export function initializeDatabase() {
  // フォルダテーブルの作成
  db.exec(`
    CREATE TABLE IF NOT EXISTS folders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      parent_id INTEGER,
      order_index INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (parent_id) REFERENCES folders (id) ON DELETE CASCADE,
      UNIQUE(name, parent_id)
    )
  `);

  // テストテーブルの作成
  db.exec(`
    CREATE TABLE IF NOT EXISTS tests (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      subject TEXT NOT NULL,
      grade TEXT NOT NULL,
      folder_id INTEGER NOT NULL,
      pdf_path TEXT,
      description TEXT,
      total_questions INTEGER,
      total_score INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (folder_id) REFERENCES folders (id) ON DELETE CASCADE
    )
  `);

  // 既存のtestsテーブルに新しいカラムを追加(存在しない場合)
  try {
    const tableInfo = db.prepare("PRAGMA table_info(tests)").all() as any[];

    const hasPdfPath = tableInfo.some((col: any) => col.name === "pdf_path");
    if (!hasPdfPath) {
      console.log("Adding pdf_path column to tests table...");
      db.exec("ALTER TABLE tests ADD COLUMN pdf_path TEXT");
      console.log("pdf_path column added successfully.");
    }

    const hasDescription = tableInfo.some(
      (col: any) => col.name === "description"
    );
    if (!hasDescription) {
      console.log("Adding description column to tests table...");
      db.exec("ALTER TABLE tests ADD COLUMN description TEXT");
      console.log("description column added successfully.");
    }

    const hasTotalQuestions = tableInfo.some(
      (col: any) => col.name === "total_questions"
    );
    if (!hasTotalQuestions) {
      console.log("Adding total_questions column to tests table...");
      db.exec("ALTER TABLE tests ADD COLUMN total_questions INTEGER");
      console.log("total_questions column added successfully.");
    }

    const hasTotalScore = tableInfo.some(
      (col: any) => col.name === "total_score"
    );
    if (!hasTotalScore) {
      console.log("Adding total_score column to tests table...");
      db.exec("ALTER TABLE tests ADD COLUMN total_score INTEGER");
      console.log("total_score column added successfully.");
    }
  } catch (error) {
    console.error("Error adding pdf_path column:", error);
  }

  // 既存のfoldersテーブルに親フォルダカラムを追加(存在しない場合)
  try {
    const folderTableInfo = db
      .prepare("PRAGMA table_info(folders)")
      .all() as any[];

    const hasParentId = folderTableInfo.some(
      (col: any) => col.name === "parent_id"
    );
    if (!hasParentId) {
      console.log("Adding parent_id column to folders table...");
      db.exec(
        "ALTER TABLE folders ADD COLUMN parent_id INTEGER REFERENCES folders(id) ON DELETE CASCADE"
      );
      console.log("parent_id column added successfully.");
    }

    const hasOrderIndex = folderTableInfo.some(
      (col: any) => col.name === "order_index"
    );
    if (!hasOrderIndex) {
      console.log("Adding order_index column to folders table...");
      db.exec("ALTER TABLE folders ADD COLUMN order_index INTEGER DEFAULT 0");
      console.log("order_index column added successfully.");

      // 既存のフォルダにorder_indexを設定
      const folders = db.prepare("SELECT id FROM folders ORDER BY id").all();
      const updateStmt = db.prepare(
        "UPDATE folders SET order_index = ? WHERE id = ?"
      );
      folders.forEach((folder: any, index: number) => {
        updateStmt.run(index, folder.id);
      });
      console.log(`Updated order_index for ${folders.length} folders.`);
    }
    
    // UNIQUE制約の確認と修正（古いUNIQUE(name)から新しいUNIQUE(name, parent_id)へ）
    const schemaInfo = db.prepare(`
      SELECT sql FROM sqlite_master 
      WHERE type='table' AND name='folders'
    `).get() as { sql: string } | undefined;
    
    if (schemaInfo && schemaInfo.sql.includes('name TEXT NOT NULL UNIQUE')) {
      console.log("⚠️  Detected old UNIQUE constraint on folders table.");
      console.log("   Please run: node migrate-folder-unique-constraint.mjs");
    }
  } catch (error) {
    console.error("Error adding parent_id column:", error);
  }

  // タグテーブルの作成
  db.exec(`
    CREATE TABLE IF NOT EXISTS tags (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      color TEXT NOT NULL DEFAULT '#3B82F6',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // テストとタグの関連テーブルの作成
  db.exec(`
    CREATE TABLE IF NOT EXISTS test_tags (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      test_id INTEGER NOT NULL,
      tag_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (test_id) REFERENCES tests (id) ON DELETE CASCADE,
      FOREIGN KEY (tag_id) REFERENCES tags (id) ON DELETE CASCADE,
      UNIQUE(test_id, tag_id)
    )
  `);

  // テストとフォルダの関連テーブルの作成(多対多)
  db.exec(`
    CREATE TABLE IF NOT EXISTS test_folders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      test_id INTEGER NOT NULL,
      folder_id INTEGER NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (test_id) REFERENCES tests (id) ON DELETE CASCADE,
      FOREIGN KEY (folder_id) REFERENCES folders (id) ON DELETE CASCADE,
      UNIQUE(test_id, folder_id)
    )
  `);

  // テスト添付ファイルテーブルの作成
  db.exec(`
    CREATE TABLE IF NOT EXISTS test_attachments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      test_id INTEGER NOT NULL,
      file_name TEXT NOT NULL,
      file_path TEXT NOT NULL,
      mime_type TEXT,
      file_size INTEGER,
      uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (test_id) REFERENCES tests (id) ON DELETE CASCADE
    )
  `);

  // 既存のtest_attachmentsテーブルに新しいカラムを追加(存在しない場合)
  try {
    const attachmentTableInfo = db
      .prepare("PRAGMA table_info(test_attachments)")
      .all() as any[];

    const hasMimeType = attachmentTableInfo.some(
      (col: any) => col.name === "mime_type"
    );
    if (!hasMimeType) {
      console.log("Adding mime_type column to test_attachments table...");
      db.exec("ALTER TABLE test_attachments ADD COLUMN mime_type TEXT");
      console.log("mime_type column added successfully.");
    }

    const hasFileSize = attachmentTableInfo.some(
      (col: any) => col.name === "file_size"
    );
    if (!hasFileSize) {
      console.log("Adding file_size column to test_attachments table...");
      db.exec("ALTER TABLE test_attachments ADD COLUMN file_size INTEGER");
      console.log("file_size column added successfully.");
    }
  } catch (error) {
    console.error("Error adding columns to test_attachments:", error);
  }

  // test_tagsテーブルにcreated_atカラムを追加
  try {
    const testTagsTableInfo = db
      .prepare("PRAGMA table_info(test_tags)")
      .all() as any[];

    const hasCreatedAt = testTagsTableInfo.some(
      (col: any) => col.name === "created_at"
    );
    if (!hasCreatedAt) {
      console.log("Adding created_at column to test_tags table...");
      db.exec("ALTER TABLE test_tags ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP");
      console.log("created_at column added successfully.");
    }
  } catch (error) {
    console.error("Error adding created_at to test_tags:", error);
  }

  // test_foldersテーブルにcreated_atカラムを追加
  try {
    const testFoldersTableInfo = db
      .prepare("PRAGMA table_info(test_folders)")
      .all() as any[];

    const hasCreatedAt = testFoldersTableInfo.some(
      (col: any) => col.name === "created_at"
    );
    if (!hasCreatedAt) {
      console.log("Adding created_at column to test_folders table...");
      db.exec("ALTER TABLE test_folders ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP");
      console.log("created_at column added successfully.");
    }
  } catch (error) {
    console.error("Error adding created_at to test_folders:", error);
  }

  // tagsテーブルにcreated_atカラムを追加
  try {
    const tagsTableInfo = db
      .prepare("PRAGMA table_info(tags)")
      .all() as any[];

    const hasCreatedAt = tagsTableInfo.some(
      (col: any) => col.name === "created_at"
    );
    if (!hasCreatedAt) {
      console.log("Adding created_at column to tags table...");
      db.exec("ALTER TABLE tags ADD COLUMN created_at DATETIME DEFAULT CURRENT_TIMESTAMP");
      console.log("created_at column added successfully.");
    }
  } catch (error) {
    console.error("Error adding created_at to tags:", error);
  }

  // 学年マスターテーブルの作成
  db.exec(`
    CREATE TABLE IF NOT EXISTS grades (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      display_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // 科目マスターテーブルの作成
  db.exec(`
    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      display_order INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // インデックスの作成(検索高速化)
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_tests_folder_id ON tests(folder_id);
    CREATE INDEX IF NOT EXISTS idx_tests_subject ON tests(subject);
    CREATE INDEX IF NOT EXISTS idx_tests_grade ON tests(grade);
    CREATE INDEX IF NOT EXISTS idx_test_tags_test_id ON test_tags(test_id);
    CREATE INDEX IF NOT EXISTS idx_test_tags_tag_id ON test_tags(tag_id);
    CREATE INDEX IF NOT EXISTS idx_test_folders_test_id ON test_folders(test_id);
    CREATE INDEX IF NOT EXISTS idx_test_folders_folder_id ON test_folders(folder_id);
    CREATE INDEX IF NOT EXISTS idx_test_attachments_test_id ON test_attachments(test_id);
    CREATE INDEX IF NOT EXISTS idx_grades_display_order ON grades(display_order);
    CREATE INDEX IF NOT EXISTS idx_subjects_display_order ON subjects(display_order);
  `);

  // 初期データの投入(フォルダが存在しない場合)
  const folderCount = db
    .prepare("SELECT COUNT(*) as count FROM folders")
    .get() as { count: number };

  if (folderCount.count === 0) {
    const insertFolder = db.prepare("INSERT INTO folders (name) VALUES (?)");
    insertFolder.run("すべてのテスト");
    insertFolder.run("未分類");
  }

  // 「未分類」フォルダが存在しない場合は追加
  const uncategorizedFolder = db
    .prepare("SELECT id FROM folders WHERE name = ?")
    .get("未分類");

  if (!uncategorizedFolder) {
    console.log('Adding "未分類" folder...');
    db.prepare("INSERT INTO folders (name) VALUES (?)").run("未分類");
    console.log('"未分類" folder added.');
  }

  // 初期学年データの投入
  const gradeCount = db
    .prepare("SELECT COUNT(*) as count FROM grades")
    .get() as { count: number };

  if (gradeCount.count === 0) {
    console.log("Adding default grades...");
    const insertGrade = db.prepare(
      "INSERT INTO grades (name, display_order) VALUES (?, ?)"
    );
    insertGrade.run("小1", 1);
    insertGrade.run("小2", 2);
    insertGrade.run("小3", 3);
    insertGrade.run("小4", 4);
    insertGrade.run("小5", 5);
    insertGrade.run("小6", 6);
    insertGrade.run("中1", 7);
    insertGrade.run("中2", 8);
    insertGrade.run("中3", 9);
    insertGrade.run("高1", 10);
    insertGrade.run("高2", 11);
    insertGrade.run("高3", 12);
    console.log("Default grades added.");
  }

  // 初期科目データの投入
  const subjectCount = db
    .prepare("SELECT COUNT(*) as count FROM subjects")
    .get() as { count: number };

  if (subjectCount.count === 0) {
    console.log("Adding default subjects...");
    const insertSubject = db.prepare(
      "INSERT INTO subjects (name, display_order) VALUES (?, ?)"
    );
    insertSubject.run("国語", 1);
    insertSubject.run("数学", 2);
    insertSubject.run("算数", 3);
    insertSubject.run("英語", 4);
    insertSubject.run("理科", 5);
    insertSubject.run("社会", 6);
    insertSubject.run("物理", 7);
    insertSubject.run("化学", 8);
    insertSubject.run("生物", 9);
    insertSubject.run("地学", 10);
    insertSubject.run("日本史", 11);
    insertSubject.run("世界史", 12);
    insertSubject.run("地理", 13);
    insertSubject.run("公民", 14);
    console.log("Default subjects added.");
  }

  // 既存データのマイグレーション: tests.folder_id から test_folders への移行
  try {
    console.log("Checking test-folder relationships migration...");

    // 全テストを取得
    const allTests = db.prepare("SELECT id, folder_id FROM tests").all() as {
      id: number;
      folder_id: number;
    }[];

    const insertTestFolder = db.prepare(
      "INSERT OR IGNORE INTO test_folders (test_id, folder_id) VALUES (?, ?)"
    );

    let migratedCount = 0;
    allTests.forEach((test) => {
      if (test.folder_id) {
        const result = insertTestFolder.run(test.id, test.folder_id);
        if (result.changes > 0) {
          migratedCount++;
        }
      }
    });

    if (migratedCount > 0) {
      console.log(`Migrated ${migratedCount} test-folder relationships.`);
    } else {
      console.log("All test-folder relationships are already up to date.");
    }
  } catch (error) {
    console.error("Error migrating test-folder relationships:", error);
  }

  // 初期データの投入(タグが存在しない場合) - サンプルデータは削除
  // ユーザーが管理者メニューから自由に作成できます

  // サンプルテストデータの投入 - 削除
  // ユーザーが自由にテストを作成できます
}

// データベース初期化の実行
initializeDatabase();

export default db;
