# フォルダ同名制約の変更適用ガイド (完全版)

**バージョン**: 2.0  
**更新日**: 2025-01-XX  
**変更内容**: 全 5 テーブルの外部キー修正を含む完全なマイグレーション手順

---

## 📝 変更内容

親フォルダが異なる場合、同名フォルダの作成を許可するように変更しました。

### 変更前

```
フォルダ/
├── テスト用/        ← 作成可能
└── 親フォルダA/
    └── テスト用/    ← エラー(同名のためNG)
```

### 変更後

```
フォルダ/
├── テスト用/        ← 作成可能
└── 親フォルダA/
    └── テスト用/    ← 作成可能(親が違うのでOK!)
```

---

## 🚨 重要: データベース整合性の修正が必要

この変更では、**5 つのテーブル**の外部キー制約を修正する必要があります:

1. **folders** テーブル - UNIQUE 制約の変更
2. **tests** テーブル - `folders_old` への参照を修正
3. **test_folders** テーブル - `tests_backup` と `folders_old` への参照を修正
4. **test_tags** テーブル - `tests_backup` への参照を修正
5. **test_attachments** テーブル - `tests_backup` への参照を修正

---

## 🛠️ 適用手順

### ステップ 1: バックアップの作成

```powershell
# データフォルダ全体をバックアップ
Copy-Item -Path "data" -Destination "data_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')" -Recurse
```

### ステップ 2: アプリケーションの停止

```powershell
# Next.jsアプリケーションを停止
# Ctrl+C または プロセスを終了
```

### ステップ 3: ファイルの配置

以下のファイルをプロジェクトルートにコピー:

#### マイグレーションスクリプト(5 個)

- `migrate-folder-unique-constraint.mjs` - folders テーブルの制約変更
- `fix-tests-foreign-key.mjs` - tests テーブルの外部キー修正
- `fix-test-folders-foreign-key.mjs` - test_folders テーブルの外部キー修正
- `fix-test-tags-foreign-key.mjs` - test_tags テーブルの外部キー修正
- `fix-test-attachments-foreign-key.mjs` - test_attachments テーブルの外部キー修正

#### 検証・テストスクリプト(2 個)

- `verify-migration.mjs` - マイグレーション検証
- `test-folder-uniqueness.mjs` - 機能テスト

#### API ファイル(2 個)

- `app/api/folders/route.ts` - フォルダ作成 API
- `app/api/folders/[id]/route.ts` - フォルダ更新 API

#### スキーマファイル

- `lib/schema.sql` - データベーススキーマ

### ステップ 4: マイグレーションの実行

**⚠️ 必ずこの順番で実行してください:**

```powershell
# 1. foldersテーブルの制約変更
node migrate-folder-unique-constraint.mjs

# 2. testsテーブルの外部キー修正
node fix-tests-foreign-key.mjs

# 3. test_foldersテーブルの外部キー修正
node fix-test-folders-foreign-key.mjs

# 4. test_tagsテーブルの外部キー修正
node fix-test-tags-foreign-key.mjs

# 5. test_attachmentsテーブルの外部キー修正
node fix-test-attachments-foreign-key.mjs
```

### ステップ 5: 検証

```powershell
# すべてのマイグレーションが正しく適用されたか検証
node verify-migration.mjs
```

**期待される出力:**

```
✅ マイグレーション検証スクリプト
==================================================
[テスト1] folders_oldへの参照チェック
  ✅ 古いテーブルへの参照なし
[テスト2] foldersテーブルの制約確認
  ✅ UNIQUE(name, parent_id)制約あり
[テスト3] testsテーブルの外部キー確認
  ✅ testsテーブル: FOREIGN KEY → folders
[テスト4] test_foldersテーブルの外部キー確認
  ✅ test_foldersテーブル: FOREIGN KEY → tests, folders
[テスト5] 未分類フォルダの確認
  ✅ 未分類フォルダ存在 (ID: X)
[テスト6] 同名フォルダの作成テスト
  ✅ 異なる親での同名フォルダ作成: 成功
  ✅ 同じ親での同名フォルダ作成: 正しくエラー
==================================================
🎉 すべての検証に合格しました!
✅ マイグレーションは正常に完了しています
✅ テスト作成機能が正常に動作するはずです
```

### ステップ 6: 機能テスト

```powershell
# フォルダ作成機能のテスト
node test-folder-uniqueness.mjs
```

**期待される出力:**

```
🎉 すべてのテストが成功しました!
✓ 同じ親フォルダ内での同名フォルダ作成を拒否
✓ 異なる親フォルダでの同名フォルダ作成を許可
✓ ルート階層での同名フォルダ作成を拒否
```

### ステップ 7: アプリケーションの起動

```powershell
npm run dev
```

### ステップ 8: 動作確認

1. ブラウザで http://localhost:3000 を開く
2. フォルダ作成機能をテスト:
   - 親フォルダ A の下に「テスト用」フォルダを作成 → 成功
   - 親フォルダ B の下に「テスト用」フォルダを作成 → 成功(同名 OK)
   - 親フォルダ A の下にもう一度「テスト用」フォルダを作成 → エラー(同じ親の下は NG)
3. テスト作成機能を確認:
   - 新しいテストを作成 → 「テストの作成に失敗しました」エラーが出ないことを確認

---

## ⚠️ トラブルシューティング

### エラー: "no such table: main.folders_old"

**原因**: マイグレーションが途中で中断された、または一部のスクリプトのみ実行された

**解決方法**:

```powershell
# 1. 残っている古いテーブル参照を確認
node -e "const db=require('better-sqlite3')('data/tests.db');db.prepare('SELECT name,sql FROM sqlite_master WHERE sql LIKE \"%folders_old%\" OR sql LIKE \"%tests_backup%\"').all().forEach(t=>console.log(t.name,t.sql))"

# 2. 該当するテーブルの修正スクリプトを再実行
# tests テーブルに問題がある場合:
node fix-tests-foreign-key.mjs

# test_folders テーブルに問題がある場合:
node fix-test-folders-foreign-key.mjs

# test_tags テーブルに問題がある場合:
node fix-test-tags-foreign-key.mjs

# test_attachments テーブルに問題がある場合:
node fix-test-attachments-foreign-key.mjs
```

### エラー: "UNIQUE constraint failed"

これは正常な動作です。同じ親フォルダ内に同名のフォルダを作成しようとした場合に発生します。

### マイグレーションに失敗した場合

```powershell
# アプリケーションを停止
# Ctrl+C

# データベースを復元
Remove-Item data\tests.db
Copy-Item data_backup_YYYYMMDD_HHMMSS\tests.db data\tests.db

# アプリケーションを再起動
npm run dev
```

---

## 📋 完全チェックリスト

適用前に必ず確認してください:

- [ ] データのバックアップを作成した
- [ ] アプリケーションを停止した
- [ ] すべてのマイグレーションスクリプト(5 個)を配置した
- [ ] 検証スクリプト(2 個)を配置した
- [ ] API ファイル(2 個)を配置した
- [ ] スキーマファイルを配置した
- [ ] `migrate-folder-unique-constraint.mjs` を実行した
- [ ] `fix-tests-foreign-key.mjs` を実行した
- [ ] `fix-test-folders-foreign-key.mjs` を実行した
- [ ] `fix-test-tags-foreign-key.mjs` を実行した
- [ ] `fix-test-attachments-foreign-key.mjs` を実行した
- [ ] `verify-migration.mjs` で検証した(すべて ✅ になった)
- [ ] `test-folder-uniqueness.mjs` でテストした(すべて成功)
- [ ] アプリケーションを起動した
- [ ] ブラウザで動作確認した
- [ ] テスト作成機能が正常に動作することを確認した

---

## 📊 技術詳細

### データベーススキーマの変更

#### folders テーブル

```sql
-- 変更前
CREATE TABLE folders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,  -- ← グローバルにユニーク
  parent_id INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES folders (id) ON DELETE CASCADE
)

-- 変更後
CREATE TABLE folders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,  -- ← UNIQUEを削除
  parent_id INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES folders (id) ON DELETE CASCADE,
  UNIQUE(name, parent_id)  -- ← 親フォルダ内でユニーク
)
```

#### tests テーブル

```sql
-- 修正前
FOREIGN KEY (folder_id) REFERENCES "folders_old" (id) ON DELETE CASCADE

-- 修正後
FOREIGN KEY (folder_id) REFERENCES folders (id) ON DELETE CASCADE
```

#### test_folders テーブル

```sql
-- 修正前
FOREIGN KEY (test_id) REFERENCES "tests_backup" (id) ON DELETE CASCADE
FOREIGN KEY (folder_id) REFERENCES "folders_old" (id) ON DELETE CASCADE

-- 修正後
FOREIGN KEY (test_id) REFERENCES tests (id) ON DELETE CASCADE
FOREIGN KEY (folder_id) REFERENCES folders (id) ON DELETE CASCADE
```

#### test_tags テーブル

```sql
-- 修正前
FOREIGN KEY (test_id) REFERENCES "tests_backup" (id) ON DELETE CASCADE

-- 修正後
FOREIGN KEY (test_id) REFERENCES tests (id) ON DELETE CASCADE
```

#### test_attachments テーブル

```sql
-- 修正前
FOREIGN KEY (test_id) REFERENCES "tests_backup" (id) ON DELETE CASCADE

-- 修正後
FOREIGN KEY (test_id) REFERENCES tests (id) ON DELETE CASCADE
```

### API 変更

#### POST /api/folders (フォルダ作成)

```typescript
// 親フォルダ内での同名チェックを追加
const checkStmt = db.prepare(
  "SELECT id FROM folders WHERE name = ? AND parent_id IS ?"
);
const existing = checkStmt.get(name, parentId);

if (existing) {
  return NextResponse.json(
    { error: "同じ親フォルダ内に同名のフォルダが既に存在します" },
    { status: 400 }
  );
}
```

#### PUT /api/folders/[id] (フォルダ更新)

```typescript
// 自分自身を除外した同名チェック
const checkStmt = db.prepare(
  "SELECT id FROM folders WHERE name = ? AND parent_id IS ? AND id != ?"
);
const duplicateFolder = checkStmt.get(name, parentId, folderId);

if (duplicateFolder) {
  return NextResponse.json(
    { error: "同じ親フォルダ内に同名のフォルダが既に存在します" },
    { status: 400 }
  );
}
```

---

## 🔧 用意されているツール・スクリプト

### マイグレーションスクリプト

1. **migrate-folder-unique-constraint.mjs**

   - folders テーブルの UNIQUE 制約を変更
   - グローバルユニーク → 親フォルダ内ユニーク

2. **fix-tests-foreign-key.mjs**

   - tests テーブルの外部キー制約を修正
   - folders_old → folders に変更

3. **fix-test-folders-foreign-key.mjs**

   - test_folders テーブルの外部キー制約を修正
   - tests_backup → tests に変更
   - folders_old → folders に変更

4. **fix-test-tags-foreign-key.mjs**

   - test_tags テーブルの外部キー制約を修正
   - tests_backup → tests に変更

5. **fix-test-attachments-foreign-key.mjs**
   - test_attachments テーブルの外部キー制約を修正
   - tests_backup → tests に変更

### デバッグ・検証ツール

6. **verify-migration.mjs**

   - すべてのマイグレーションが正しく適用されたか検証
   - 6 つの自動テストを実行
   - 古いテーブル参照の有無を確認

7. **test-folder-uniqueness.mjs**
   - フォルダ作成機能の動作テスト
   - 3 つのシナリオをテスト

---

## 🎯 期待される動作

### 正常に作成できる例

```typescript
// ケース1: 異なる親フォルダ
親A/テスト用/  ← OK
親B/テスト用/  ← OK (親が違うので許可)

// ケース2: ルート階層と子階層
/テスト用/      ← OK
/親A/テスト用/  ← OK (階層が違うので許可)
```

### エラーになる例

```typescript
// ケース1: 同じ親フォルダ内
親A/テスト用/  ← OK
親A/テスト用/  ← NG (同じ親の下に同名は不可)

// ケース2: 同じルート階層
/テスト用/     ← OK
/テスト用/     ← NG (同じルート階層に同名は不可)
```

---

## 📝 バージョン履歴

### v2.0 (2025-01-XX)

- test_tags テーブルの外部キー修正を追加
- test_attachments テーブルの外部キー修正を追加
- 合計 5 テーブルの外部キー修正に対応
- verify-migration.mjs による完全な検証機能を追加
- エラーメッセージの明確化

### v1.2 (2025-01-XX)

- tests テーブルの外部キー修正を追加
- test_folders テーブルの外部キー修正を追加
- "no such table: main.folders_old"エラーのトラブルシューティングを追加

### v1.1 (2025-01-XX)

- マイグレーション手順の詳細化
- test-folder-uniqueness.mjs によるテスト機能追加

### v1.0 (2025-01-XX)

- 初版: フォルダ UNIQUE 制約の変更
- API 更新

---

## 📞 サポート

問題が発生した場合:

1. `verify-migration.mjs` で現在の状態を確認
2. エラーメッセージを確認
3. トラブルシューティングセクションを参照
4. バックアップからの復元を検討

---

**このドキュメントは、既存システムへの変更適用を安全に行うためのガイドです。**  
**必ずバックアップを取ってから作業を開始してください。**
