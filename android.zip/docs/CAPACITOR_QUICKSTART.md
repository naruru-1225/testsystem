# 🚀 Capacitor Android 化 実行手順

## ✅ 現在の状況

- ✅ Capacitor インストール済み (`@capacitor/core`)
- ✅ Next.js ビルド成功
- ✅ API Routes 維持（`output: "export"`は未使用）

---

## 📋 次のステップ

### ステップ 1: Android プラットフォームを追加

```bash
npm install @capacitor/android
npm run cap:add:android
```

これにより`android/`ディレクトリが作成されます。

### ステップ 2: capacitor.config.ts を環境に合わせて修正

現在の設定:

```typescript
server: {
  url: "http://192.168.1.64:3000", // ← あなたのローカルIPに変更
  cleartext: true,
}
```

**あなたのローカル IP を確認:**

PowerShell で:

```powershell
ipconfig
```

`IPv4 アドレス`を`capacitor.config.ts`の`url`に設定してください。

### ステップ 3: Next.js サーバーを起動

別のターミナルで:

```bash
npm run dev
# または本番ビルド後
npm run build
npm start
```

サーバーが`http://localhost:3000`で起動していることを確認。

### ステップ 4: Android ビルド

```bash
npm run android:dev
```

これは以下を実行します:

1. `npm run build` - Next.js ビルド
2. `cap sync` - Capacitor と Android の同期
3. `cap open android` - Android Studio を開く

### ステップ 5: Android Studio でビルド

Android Studio が開いたら:

1. **Gradle 同期を待つ** (初回は時間がかかります)
2. **エミュレーターを起動** または **実機を接続**
3. **Run (▶)** ボタンをクリック

---

## 🎯 動作確認

### アプリ起動後の確認項目

1. ✅ アプリが起動する
2. ✅ トップページが表示される
3. ✅ テスト一覧が表示される（API から取得）
4. ✅ フォルダフィルタが動作する
5. ✅ 検索が動作する
6. ✅ テスト詳細が表示される
7. ✅ PDF 表示が動作する

### トラブルシューティング

#### 問題: アプリが真っ白

**原因:** Next.js サーバーが起動していない

**解決策:**

```bash
# 別のターミナルで
npm run dev
```

#### 問題: "接続できません"エラー

**原因:** ローカル IP が間違っている

**解決策:**

1. `ipconfig`で IP を確認
2. `capacitor.config.ts`の`url`を修正
3. `npm run cap:sync`を再実行

#### 問題: "Cleartext HTTP traffic not permitted"

**解決策:** `android/app/src/main/AndroidManifest.xml`を編集

```xml
<application
    android:usesCleartextTraffic="true"
    ...>
```

---

## 📱 本番ビルド手順

### APK ファイル生成

1. **本番ビルド**

   ```bash
   npm run build
   npm run cap:sync
   ```

2. **Android Studio でビルド**

   - `Build` → `Build Bundle(s) / APK(s)` → `Build APK(s)`
   - 生成された APK は`android/app/build/outputs/apk/debug/`に保存

3. **署名付き APK（リリース用）**
   - `Build` → `Generate Signed Bundle / APK`
   - キーストアを作成（初回のみ）
   - パスワードとエイリアスを設定

---

## 🔧 高度な設定

### webDir を変更する場合

**現在の設定:**

```typescript
webDir: ".next/standalone/public",
```

**静的エクスポートする場合:**

1. `next.config.ts`を修正:

   ```typescript
   output: "export",
   ```

2. `capacitor.config.ts`を修正:

   ```typescript
   webDir: "out",
   ```

3. API Routes を外部 API に切り替え（別サーバー必要）

### オフライン対応

Service Worker と IndexedDB を実装:

```bash
npm install workbox-webpack-plugin
npm install dexie
```

---

## 📊 アーキテクチャ図

```
┌─────────────────────────────────────┐
│   Androidアプリ (WebView)            │
│   - Capacitor                       │
│   - HTML/CSS/JavaScript             │
└──────────────┬──────────────────────┘
               │ HTTP (192.168.1.64:3000)
               ▼
┌─────────────────────────────────────┐
│   Next.jsサーバー (開発PC)           │
│   - API Routes                      │
│   - SQLite Database                 │
│   - ファイルストレージ                │
└─────────────────────────────────────┘
```

---

## ✅ チェックリスト

### 開発環境セットアップ

- [x] `@capacitor/core`インストール
- [x] `@capacitor/cli`インストール
- [x] `npx cap init`実行
- [ ] `@capacitor/android`インストール
- [ ] `npm run cap:add:android`実行
- [ ] `capacitor.config.ts`の IP アドレス設定
- [ ] Next.js サーバー起動確認

### ビルドとデプロイ

- [x] `npm run build`成功
- [ ] `npm run cap:sync`実行
- [ ] Android Studio で開く
- [ ] エミュレーターで動作確認
- [ ] 実機で動作確認

### 機能テスト

- [ ] アプリ起動
- [ ] テスト一覧表示
- [ ] 検索機能
- [ ] フィルタ機能
- [ ] テスト詳細表示
- [ ] PDF 表示
- [ ] 新規作成
- [ ] 編集

---

## 🆘 サポート

問題が発生した場合:

1. **Android Studio Logcat**を確認
2. **Chrome DevTools**でデバッグ (`chrome://inspect`)
3. **Next.js サーバーログ**を確認

---

## 📚 参考リンク

- [Capacitor 公式ドキュメント](https://capacitorjs.com/docs)
- [Next.js with Capacitor](https://capacitorjs.com/docs/guides/nextjs)
- [Android 開発者ガイド](https://developer.android.com/studio)
