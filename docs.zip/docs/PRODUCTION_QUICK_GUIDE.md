# 本番環境マイグレーション - 完全実行ガイド

## 📋 前提条件

- [ ] アプリケーションを停止した
- [ ] データベースのバックアップを作成した
- [ ] すべてのマイグレーションファイルを配置した

---

## 🚀 実行手順(コピー&ペースト用)

### ステップ 0: 作業ディレクトリに移動

```powershell
cd C:\Users\管理者ユーザー\Desktop\testproject
```

### ステップ 1: 現在の状態を確認

```powershell
node check-migration-status.mjs
```

**期待される出力**: 次に実行すべきステップが表示されます

---

### ステップ 2: バックアップ作成(まだの場合)

```powershell
Copy-Item -Path "data" -Destination "data_backup_$(Get-Date -Format 'yyyyMMdd_HHmmss')" -Recurse
```

**確認**: `data_backup_YYYYMMDD_HHMMSS` フォルダが作成されたことを確認

---

### ステップ 3: マイグレーション実行

#### 方法 A: 一括実行(推奨)

```powershell
node run-all-migrations.mjs
```

**この方法の利点**:

- すべてのステップを自動実行
- エラーがあれば自動停止
- どこまで完了したか表示

---

#### 方法 B: 個別実行(トラブル時)

```powershell
# ステップ1
node migrate-folder-unique-constraint.mjs
```

**出力例**:

```
✅ マイグレーション完了!
移行されたフォルダ数: XX件
✅ 外部キー制約が正しく修正されました!
   UNIQUE(name, parent_id)
```

成功したら次へ:

```powershell
# ステップ2
node fix-tests-foreign-key.mjs
```

**出力例**:

```
✅ マイグレーション完了!
移行されたテスト数: XX件
✅ 外部キー制約が正しく修正されました!
   FOREIGN KEY (folder_id) REFERENCES folders
```

成功したら次へ:

```powershell
# ステップ3
node fix-test-folders-foreign-key.mjs
```

成功したら次へ:

```powershell
# ステップ4
node fix-test-tags-foreign-key.mjs
```

成功したら次へ:

```powershell
# ステップ5
node fix-test-attachments-foreign-key.mjs
```

---

### ステップ 4: 検証

```powershell
node verify-migration.mjs
```

**期待される出力**:

```
✅ マイグレーション検証スクリプト
==================================================
[テスト1] folders_oldへの参照チェック
  ✅ 古いテーブルへの参照なし
[テスト2] foldersテーブルの制約確認
  ✅ UNIQUE(name, parent_id)制約あり
[テスト3] testsテーブルの外部キー確認
  ✅ testsテーブル: FOREIGN KEY → folders
[テスト4] test_foldersテーブルの外部キー確認
  ✅ test_foldersテーブル: FOREIGN KEY → tests, folders
[テスト5] 未分類フォルダの確認
  ✅ 未分類フォルダ存在 (ID: X)
[テスト6] 同名フォルダの作成テスト
  ✅ 異なる親での同名フォルダ作成: 成功
  ✅ 同じ親での同名フォルダ作成: 正しくエラー
==================================================
🎉 すべての検証に合格しました!
```

すべて ✅ が表示されれば成功です!

---

### ステップ 5: アプリケーション起動

```powershell
npm run dev
```

---

## ❌ エラーが発生した場合

### エラー 1: "Cannot find module"

**原因**: ファイルが配置されていない、またはファイル名のスペルミス

**解決**:

```powershell
# ファイルの存在を確認
Get-ChildItem -Filter "*.mjs" | Select-Object Name
```

必要なファイルがない場合は、開発環境からコピー

---

### エラー 2: "no such table: main.folders_old"

**原因**: ステップ 1 を実行せずにステップ 2 以降を実行した

**解決**:

```powershell
# 現在の状態を確認
node check-migration-status.mjs

# ステップ1から実行
node migrate-folder-unique-constraint.mjs
```

---

### エラー 3: "UNIQUE constraint failed"

**原因**: すでに同名のフォルダが存在する

**これは正常な動作です** - マイグレーション自体は成功しています

---

### エラー 4: その他のエラー

**解決手順**:

1. **エラーメッセージをコピー**

2. **データベースを復元**:

```powershell
# アプリケーションを停止(Ctrl+C)

# データベースを復元
Remove-Item data\tests.db
Copy-Item data_backup_YYYYMMDD_HHMMSS\tests.db data\tests.db
```

3. **状態を確認**:

```powershell
node check-migration-status.mjs
```

4. **再度実行**

---

## 🎯 クイックリファレンス

### 完全実行(最初から)

```powershell
cd C:\Users\管理者ユーザー\Desktop\testproject
node check-migration-status.mjs
node run-all-migrations.mjs
node verify-migration.mjs
npm run dev
```

### 個別実行(トラブル時)

```powershell
cd C:\Users\管理者ユーザー\Desktop\testproject
node migrate-folder-unique-constraint.mjs
node fix-tests-foreign-key.mjs
node fix-test-folders-foreign-key.mjs
node fix-test-tags-foreign-key.mjs
node fix-test-attachments-foreign-key.mjs
node verify-migration.mjs
npm run dev
```

### 復元(エラー時)

```powershell
cd C:\Users\管理者ユーザー\Desktop\testproject
# アプリケーション停止(Ctrl+C)
Remove-Item data\tests.db
Copy-Item data_backup_YYYYMMDD_HHMMSS\tests.db data\tests.db
npm run dev
```

---

## ✅ 成功確認チェックリスト

- [ ] `node check-migration-status.mjs` - 「すべて完了」と表示
- [ ] `node verify-migration.mjs` - すべて ✅ が表示
- [ ] `npm run dev` - アプリケーションが起動
- [ ] ブラウザでアクセス - 正常に表示される
- [ ] フォルダ作成 - 異なる親で同名フォルダが作成できる
- [ ] テスト作成 - エラーなく作成できる

---

**🎉 すべて完了したら、マイグレーション成功です!**
